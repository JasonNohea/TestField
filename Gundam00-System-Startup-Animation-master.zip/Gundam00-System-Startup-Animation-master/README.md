# Gundam00-System-Startup-Animation
A gundam 00 system startup animation written with [p5.js](https://github.com/processing/p5.js). 

Still working on the pop windows. Hope gundam fans would like it.

### Font

The font in seems to be a font created exclusively for the animation and wasn't able to be find anywhere in the internet. Luckily some guys created a custom font based on the animation on [FontStruct](https://fontstruct.com/fontstructions/show/448380/a_mun_celestial_1). Thanks to the great work of `A-Mun Celestial`, `HeadsUpDesign`. However the original font has some details of error, so the font used in this project was [a patched version](https://fontstruct.com/fontstructions/show/1407364/celestial-being-font) based on `HeadsUpDesign`'s work.

### Screen Compatibility

This animation was designed to adapt to the width of different screen resoutions. Yet some problems still remains, so there will be a minimum recommend resolution width of 800px. 

### Demo
http://gundam.dreamisty.com


